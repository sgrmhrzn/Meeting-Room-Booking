import { MeetingDateValidatePipe } from './meeting-date-validate.pipe';

describe('MeetingDateValidatePipe', () => {
  it('create an instance', () => {
    const pipe = new MeetingDateValidatePipe();
    expect(pipe).toBeTruthy();
  });
});
