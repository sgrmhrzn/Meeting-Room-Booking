import { RoomFilterPipe } from './room-filter.pipe';

describe('RoomFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new RoomFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
